package ba.hackenschmied.server;
/* Base code by Maximilian Peter Hackenschmied */
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * Server that handles communication between smartphone and Arduino
 * 
 * @author Max
 * 
 */
public class Server {

	/**
	 * Server ID
	 */
	private String myID = "S";

	/**
	 * ID of periscope phone
	 */
	private String periscopeID = "P";

	/**
	 * Server port
	 */
	private static final int PORT = 4321;

	/**
	 * Output for Server.
	 */
	private PrintWriter out;

	/**
	 * Manages all connected sockets and their client's IDs.
	 */
	HashMap<String, Socket> connectionsMap = new HashMap<String, Socket>();

	/**
	 * Instance of Periscope-Server GUI.
	 */
	GUI gui;

	/**
	 * Instance of SensorCommunicator.
	 */
//	SensorCommunicator sensorCommunicator;

	/**
	 * Instance of SensorCommunicator.
	 */
//	HeartbeatPlayer player;

	/**
	 * Variables to save user inputs of left climate popup
	 */
	private int temperatureLeft = 21;
	private Boolean blowerWindshield = false;
	private Boolean blowerLeftHead = true;
	private Boolean blowerLeftFoot = false;
	private float blowerLeftPower = 2.5f;

	/**
	 * Variables to save user inputs of right climate popup
	 */
	private int temperatureRight = 21;
	private Boolean blowerRightHead = true;
	private Boolean blowerRightFoot = true;
	private float blowerRightPower = 3.0f;

	private static int anzahlClients = 0;
	static String message;

	/**
	 * 
	 * @param args
	 */
	public Server() {

		ServerListener listener = new ServerListener(this);
		Thread t = new Thread(listener);
		t.start();

		this.gui = new GUI();
		gui.setServer(this);

		//sensorCommunicator = new SensorCommunicator(this);

	}

	private void initiateVariables() {
	}

	/**********************************************************************************************************************************/
	/* Methods for socket communication */
	/**********************************************************************************************************************************/

	/**
	 * Sends message to all connected clients.
	 * 
	 * @param message
	 *            Message to send.
	 */
	public void sendToAll(String message) {
		Iterator it = connectionsMap.entrySet().iterator();
		while (it.hasNext()) {
			Map.Entry pairs = (Map.Entry) it.next();
			Socket socket = (Socket) pairs.getValue();
			System.out.println(pairs.getKey() + " = " + pairs.getValue());
			try {
				out = new PrintWriter(socket.getOutputStream(), true);
				out.println(message);
				gui.setMessage("Server sendet: " + message);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * Sends a message to the client with destID
	 * 
	 * @param destID
	 * @param srcID
	 * @param message
	 */
	public void sendToClient(String destID, String srcID, String message) {
		System.out.println("SENDE: " + destID + ";" + srcID + ";" + message);
		System.out.println("");
		Socket socket = (Socket) connectionsMap.get(destID);
		if (socket != null) {
			try {
				out = new PrintWriter(socket.getOutputStream(), true);
				out.println(destID + ";" + srcID + ";" + message);
			} catch (IOException e) {
				e.printStackTrace();
				System.err.println("Konnte nicht gesendet werden.");
			}
		} else {
			System.err.println("Kein Client mit ID " + destID + " verbunden.");
		}

	}

	/**
	 * Sends a request to get the client's ID
	 * 
	 * @param socket
	 *            Socket to client.
	 */
	public void requestID(Socket socket) {
		try {
			out = new PrintWriter(socket.getOutputStream(), true);
			out.println("getID");
			System.out.println("id requested");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Manages incoming messages.
	 */
	public static class MessageListener implements Runnable {

		Socket socket;
		BufferedReader reader;
		String id;
		String destID;
		String srcID;
		String msg;
		Thread thread = null;

		Boolean shouldrun = true;
		Server server;

		public MessageListener(Socket s, Server ser) {

			try {
				server = ser;
				socket = s;
				reader = new BufferedReader(new InputStreamReader(
						socket.getInputStream()));
			} catch (IOException e) {
				e.printStackTrace();
			}

			// request the client's id
			server.requestID(socket);
		}

		public void start() {

			System.out.println("run()");
			while (shouldrun) {
				try {

					// if (reader.ready()) {
					message = reader.readLine();

					// }
					if (!message.isEmpty()) {
						if (message != null) {
							System.out.println("MESSAGE bekommen: " + message);
							if (message.contains("sendID")) {
								String[] m = message.split(";");
								id = m[1];
								saveClientID(m[1]);

							} else {
								server.interpretMessage(message);
							}
						}
					}

				} catch (IOException e) {
//					System.out.println("Client Disconnected. IOE");
//					server.connectionsMap.remove(id);
					shouldrun = false;
//					e.printStackTrace();
				} catch (NullPointerException e) {
//					System.out.println("Client Disconnected. NP");
//					server.connectionsMap.remove(id);
					shouldrun = false;
//					e.printStackTrace();
				} catch (Exception e) {
//					System.out.println("Client Disconnected. E");
//					server.connectionsMap.remove(id);
					shouldrun = false;
//					e.printStackTrace();
				}
			}
		}

		private void saveClientID(String id) {
			if (server.connectionsMap.containsKey(id)) {
				server.connectionsMap.remove(id);
			}
			server.connectionsMap.put(id, socket);
			anzahlClients = server.connectionsMap.size();
			System.out.println("Client ist: " + id);
			System.out.println("Angemeldete Clients: "
					+ server.connectionsMap.size());
			System.out.println("");
//			System.out.println("Send current temperature values to client");
			// send current temperature values to client
			server.sendHotspotAtStart(id);
		}

		@Override
		public void run() {
			this.start();

		}
	}

	/**
	 * Manages incoming clients.
	 */
	public class ServerListener implements Runnable {

		Server server;

		public ServerListener(Server s) {
			server = s;
		}

		@Override
		public void run() {
			ServerSocket server = null;
			try {
				server = new ServerSocket(PORT);
			} catch (IOException e1) {
				// e1.printStackTrace();
			}
			while (anzahlClients < 3) {
				try {
					System.out.println("waiting...");
					Socket socket = server.accept();
					System.out
							.println("______________________________________________________");
					System.out.println("New Client Connected!");
					MessageListener ml = new MessageListener(socket,
							this.server);
					Thread t = new Thread(ml);
					t.start();

				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}

	/**********************************************************************************************************************************/
	/* Methods for reacting to received messages from clients */
	/**********************************************************************************************************************************/

	static final String befehlShowPeriscopeIcon = "ShowPeriscopeIcon";
	static final String befehlSaveTemp = "SaveTemp";
	static final String befehlGetClimateVariables = "GetClimateVariables";
	static final String befehlSaveBlowers = "SaveBlowers";
	static final String befehlSavePower = "SavePower";


	/**
	 * Interprets messages from clients
	 */
	public void interpretMessage(String message) {
		if (message != null && message.contains(";")) {
			String[] m = message.split(";");
			if (message.contains(befehlSaveTemp)) {
				changeTemp(m[1], m[2]);
			} else if (message.contains(befehlSavePower)) {
				changeBlowerpower(m[3], m[4]);
			} else if (message.contains(befehlSaveBlowers)) {
				saveBlowers(m[3]);
			} else if (message.contains("SwipeToOther")) {
				sendSwipeOrder(message);
			} else if (message.contains(befehlShowPeriscopeIcon)) {
				sendToClient("CD", periscopeID, befehlShowPeriscopeIcon);
			} else if (message.contains("GetHotspotNr")) {
				sendToClient("CD", "S", "hotspotNr;" + hotspotNr + ";");
			} else if (message.contains("Play")) {
				sendToClient(m[0], m[1], "Play" + ";" + m[3] + ";" + m[4] + ";");
			} else if (message.contains("Pause")) {
				sendToClient(m[0], m[1], "Pause");
			} else if (message.contains("NewSong")) {
				sendToClient(m[0], m[1], "NewSong" + ";" + m[3] + ";");
			} else if (message.contains("Shuffle")) {
				sendToClient(m[0], m[1], "Shuffle" + ";" + m[3] + ";");
			} else if (message.contains("Repeat")) {
				sendToClient(m[0], m[1], "Repeat" + ";" + m[3] + ";");
			} else if (message.contains("playHotspot")) {
				sendToClient("CD", "RD", m[2] + ";" + m[3] + ";");
			} else if (message.contains("stopHotspot")) {
				sendToClient("CD", "RD", "stopHotspot;");
			} else if (message.contains("sendHotspot")) {
				String msg = m[3];
				hotspotNr = Integer.parseInt(msg);
				sendHotspot(hotspotNr);
			} else if (message.contains("SwipeOut")) {
				String receiver = m[0];
				String sender = m[1];
				String msg = m[2];
				sendToClient(receiver, sender, msg);
			} else {

				printOut(message);

			}
		} else {
			printOut("ERROR!: " + message);
		}
	}

	private void saveBlowers(String blower) {
		System.out.println("Server speichert: " + blower);
		if (blower.contains("leftHeadOn")) {
			blowerLeftHead = true;
		} else if (blower.contains("leftHeadOff")) {
			blowerLeftHead = false;
		} else if (blower.contains("leftFootOn")) {
			blowerLeftFoot = true;
		} else if (blower.contains("leftFootOff")) {
			blowerLeftFoot = false;
		} else if (blower.contains("rightHeadOn")) {
			blowerRightHead = true;
		} else if (blower.contains("rightHeadOff")) {
			blowerRightHead = false;
		} else if (blower.contains("rightFootOn")) {
			blowerRightFoot = true;
		} else if (blower.contains("rightFootOff")) {
			blowerRightFoot = false;
		} else if (blower.contains("windshieldOn")) {
			blowerWindshield = true;
		} else if (blower.contains("windshieldOff")) {
			blowerWindshield = false;
		}

	}

	/**
	 * 
	 */
	public void sendSwipeOrder(String message) {
		String[] m = message.split(";");
		String receiver = m[0];
		String sender = m[1];
		String msg;
		msg = m[2] + ";" + m[3] + ";" + m[4] + ";";
		
		sendToClient(receiver, sender, msg);
	}

	/**
	 * 
	 */
	public void printOut(String message) {
		System.out
				.println("Server hat Message empfangen, wird nicht interpretiert: "
						+ message);
	}

	/**
	 * Send current climate values to client
	 */
	public void sendHotspotAtStart(String id) {
		sendToClient(id, "S",
				"CurrentHotspot;" + hotspotNr + ";");
	}

	/**
	 * 
	 */
	public void changeBlowerpower(String side, String power) {
		if (side.contains("left")) {
			blowerLeftPower = Float.parseFloat(power);
		} else if (side.contains("right")) {
			blowerRightPower = Float.parseFloat(power);
		}
		System.out.println("Power of Blowers " + side + "changed: " + power);
	}

	/**
	 * Saves users' changes of temperature (for updates on other screens or
	 * restart of the system)
	 * 
	 * @param side
	 * @param upOrDown
	 */
	private void changeTemp(String side, String upOrDown) {
		if (side.contains("left")) {
			if (upOrDown.contains("up")) {
				temperatureLeft++;
			} else {
				temperatureLeft--;
			}
		} else if (side.contains("right")) {
			if (upOrDown.contains("up")) {
				temperatureRight++;
			} else {
				temperatureRight--;
			}
		}
//		System.out.println("Temperature changed. Left side: " + temperatureLeft
//				+ "�C, right side:" + temperatureRight + "�C");
	}

	/**********************************************************************************************************************************/
	/* Manages communication with arduino and interpretation of arduino messages */
	/**********************************************************************************************************************************/

	/**
	 * Interprets incoming messages for sensors.
	 * 
	 * @param inputLine
	 */
	public void interpretSensor(String inputLine) {
//		System.out.println("SERVER HAT BEKOMMEN: " + inputLine);
		if (inputLine != null) {
			if (inputLine.contains("FeelbuttonOn")) {
				sendToAll("ALL;A;startApp");
				startHeartbeatPlayer();
				System.out.println("START HEARTBEAT PLAYER");
			} else if (inputLine.contains("FeelbuttonOff")) {
				System.out.println("SENDE CLIENT");
				stopHeartbeatPlayer();
				sendToAll("ALL;A;stopApp");
			} else if (inputLine.contains("agilemode")) {
				changeHeardbeatSpeed(2);
				sendToClient("CD", "A", "agilemode");
			} else if (inputLine.contains("ecomode")) {
				sendToClient("CD", "A", "ecomode");
				changeHeardbeatSpeed(3);
			} else if (inputLine.contains("leftButtonOn")) {
				sendToClient("CD", "A", "showClimaLeft");
			} else if (inputLine.contains("leftButtonOff")) {
				sendToClient("CD", "A", "hideClimaLeft");
			} else if (inputLine.contains("middleButtonOn")) {
				sendToClient("CD", "A", "showAudio");
			} else if (inputLine.contains("middleButtonOff")) {
				sendToClient("CD", "A", "hideAudio");
			} else if (inputLine.contains("rightButtonOn")) {
				sendToClient("CD", "A", "showClimaRight");
			} else if (inputLine.contains("rightButtonOff")) {
				sendToClient("CD", "A", "hideClimaRight");
			} else if (inputLine.contains("Volume")) {
				String[] m = inputLine.split(" ");
				int volume = Integer.parseInt(m[1]);
				sendToClient("CD", "A", "changeRadioVolume;" + volume + ";");
			}

		}
	}

	public void sendShowRadio() {
		sendToClient("CD", "A", "showAudio");
	}

	public void sendHideRadio() {
		sendToClient("CD", "A", "hideAudio");
	}

	public void sendHideEnergy() {
		sendToClient("CD", "A", "hideEnergy");
	}

	public void sendShowEnergy() {
		sendToClient("CD", "A", "showEnergy");
	}

	public void sendShowClimateLeft() {
		sendToClient("CD", "A", "showClimaLeft");
	}

	public void sendHideClimateLeft() {
		sendToClient("CD", "A", "hideClimaLeft");
	}

	public void sendShowClimateRight() {
		sendToClient("CD", "A", "showClimaRight");
	}

	public void sendHideClimateRight() {
		sendToClient("CD", "A", "hideClimaRight");
	}

	public void sendEngineStarted() {
		sendToAll("ALL;A;startApp");
	}

	public void sendEngineStopped() {
		sendToAll("ALL;A;stopApp");
	}

	public void sendRadioVolume(int volume) {
		sendToAll("ALL;A;changeRadioVolume;" + volume + ";");
	}

	public void sendAgile() {
		sendToClient("CD", "A", "agilemode");
	}

	public void sendEco(int volume) {
		sendToClient("CD", "A", "ecomode");
	}

	/**********************************************************************************************************************************/
	/* Messages from Periscope */
	/**********************************************************************************************************************************/
	private int hotspotNr = 0;
	static final String calibrateYaw = "calibrateYaw";
	static final String direction = "direction";

	public void sendCalibrateYaw() {
		sendToAll(calibrateYaw);
	}

	public void sendDirection() {
		sendToAll(direction);
	}

	public void sendHotspot(int i) {
		hotspotNr = i;
		if (i > 0) {
			sendToClient("RD", "P", "showPeriscopeIcon;" + hotspotNr + ";");
		} else if (i == 0) {
			sendToClient("RD", "P", "hidePeriscopeIcon;");
		}
	}

	/**********************************************************************************************************************************/
	/* Heartbeat */
	/**********************************************************************************************************************************/

	public void startHeartbeatPlayer() {
//		player = new HeartbeatPlayer();
//		player.playing = true;
//		player.start();
	}

	public void stopHeartbeatPlayer() {
//		player.playing = false;
	}

	public void changeHeardbeatSpeed(int speed) {
//		player.changeSpeed(speed);
	}

}
