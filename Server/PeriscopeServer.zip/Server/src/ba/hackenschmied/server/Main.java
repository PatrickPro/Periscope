package ba.hackenschmied.server;
/* Base code by Maximilian Peter Hackenschmied */
public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println("STARTING");
		new Server();
		
	}

}
