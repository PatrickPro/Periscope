package ba.hackenschmied.server;
/* Base code by Maximilian Peter Hackenschmied */
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

/**
 * GUI of the Periscope-Server.
 * 
 * @author Max
 * 
 */
public class GUI implements ActionListener {

	private static final String NEWLINE = "\n";
	private static final String TITLE = "Periscope-Server";

	private Server server;

	private JFrame frame;
	private JTextField textfield;
	private JTextArea textarea;
	private JScrollPane sp;
	private JButton btn_calibrate, btn_direction, btn_audio_on, btn_audio_off,
			btn_feel_on, btn_feel_off, btn_start_engine, btn_audio_volume_up,
			btn_climate_left_on, btn_climate_left_off, btn_climate_right_on,
			btn_climate_right_off, btn_stop_engine, btn_speed_slow,
			btn_speed_moderate, btn_speed_fast, btn_audio_volume_down,
			btn_hotspot_1, btn_hotspot_2, btn_hotspot_3, btn_no_hotspot,
			btn_eco, btn_agile;
	private String message = "";

	public GUI() {

		System.out.println("starting gui");

		initGUI();
	}

	/**
	 * Initiiert die GUI
	 */
	private void initGUI() {

		frame = new JFrame(TITLE);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLayout(new FlowLayout());

		textfield = new JTextField("", 20);
		textarea = new JTextArea(3, 20);
		sp = new JScrollPane(textarea);
		textarea.setEditable(false);

		btn_calibrate = new JButton();
		btn_calibrate.setText("Calibrate Periscope");
		btn_calibrate.addActionListener(this);

		btn_direction = new JButton();
		btn_direction.setText("Change Direction Periscope");
		btn_direction.addActionListener(this);

		// Buttons
		btn_audio_on = new JButton();
		btn_audio_on.setText("Audio button ON");
		btn_audio_on.addActionListener(this);

		btn_audio_off = new JButton();
		btn_audio_off.setText("Audio button OFF");
		btn_audio_off.addActionListener(this);

		btn_audio_volume_up = new JButton();
		btn_audio_volume_up.setText("Audio Volume 5");
		btn_audio_volume_up.addActionListener(this);

		btn_audio_volume_down = new JButton();
		btn_audio_volume_down.setText("Audio Volume 3");
		btn_audio_volume_down.addActionListener(this);

		btn_feel_on = new JButton();
		btn_feel_on.setText("Feelbutton ON");
		btn_feel_on.addActionListener(this);

		btn_feel_off = new JButton();
		btn_feel_off.setText("Feelbutton OFF");
		btn_feel_off.addActionListener(this);

		btn_start_engine = new JButton();
		btn_start_engine.setText("Start engine");
		btn_start_engine.addActionListener(this);

		btn_stop_engine = new JButton();
		btn_stop_engine.setText("Stop engine");
		btn_stop_engine.addActionListener(this);

		btn_climate_left_on = new JButton();
		btn_climate_left_on.setText("Left climate button ON");
		btn_climate_left_on.addActionListener(this);

		btn_climate_left_off = new JButton();
		btn_climate_left_off.setText("Left climate button OFF");
		btn_climate_left_off.addActionListener(this);

		btn_climate_right_on = new JButton();
		btn_climate_right_on.setText("Right climate button ON");
		btn_climate_right_on.addActionListener(this);

		btn_climate_right_off = new JButton();
		btn_climate_right_off.setText("Right climate button OFF");
		btn_climate_right_off.addActionListener(this);

		btn_speed_slow = new JButton();
		btn_speed_slow.setText("Drive Slow");
		btn_speed_slow.addActionListener(this);

		btn_speed_moderate = new JButton();
		btn_speed_moderate.setText("Drive moderate");
		btn_speed_moderate.addActionListener(this);

		btn_speed_fast = new JButton();
		btn_speed_fast.setText("Drive fast");
		btn_speed_fast.addActionListener(this);

		btn_hotspot_1 = new JButton();
		btn_hotspot_1.setText("Hotspot 1");
		btn_hotspot_1.addActionListener(this);

		btn_hotspot_2 = new JButton();
		btn_hotspot_2.setText("Hotspot 2");
		btn_hotspot_2.addActionListener(this);

		btn_hotspot_3 = new JButton();
		btn_hotspot_3.setText("Hotspot 3");
		btn_hotspot_3.addActionListener(this);

		btn_no_hotspot = new JButton();
		btn_no_hotspot.setText("No Hotspot");
		btn_no_hotspot.addActionListener(this);

		btn_eco = new JButton();
		btn_eco.setText("Eco");
		btn_eco.addActionListener(this);

		btn_agile = new JButton();
		btn_agile.setText("Agile");
		btn_agile.addActionListener(this);

		frame.add(textarea);
		frame.add(btn_start_engine);
		frame.add(btn_audio_on);
		frame.add(btn_audio_off);
		frame.add(btn_audio_volume_up);
		frame.add(btn_feel_on);
		frame.add(btn_feel_off);
		frame.add(btn_stop_engine);
		frame.add(btn_climate_left_on);
		frame.add(btn_climate_left_off);
		frame.add(btn_climate_right_on);
		frame.add(btn_climate_right_off);

		frame.add(btn_speed_slow);
		frame.add(btn_speed_moderate);
		frame.add(btn_speed_fast);

		frame.add(btn_audio_volume_down);
		frame.add(btn_hotspot_1);
		frame.add(btn_hotspot_2);
		frame.add(btn_hotspot_3);
		frame.add(btn_no_hotspot);

		frame.add(btn_calibrate);
		frame.add(btn_direction);

		frame.add(btn_eco);
		frame.add(btn_agile);

		frame.setSize(1200, 200);
		frame.setVisible(true);
	}

	public void setServer(Server s) {
		this.server = s;
	}

	public void setMessage(String message) {
		System.out.println("Setting Message: " + message);
		this.message = this.message + "\n" + message;
		// this.textarea.append(message+NEWLINE);
		this.textarea.setText(NEWLINE + message);
		textarea.setCaretPosition(textarea.getDocument().getLength());
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub

		if (e.getSource() == btn_feel_on) {
			server.sendShowEnergy();
		} else if (e.getSource() == btn_feel_off) {
			server.sendHideEnergy();
		} else if (e.getSource() == btn_audio_on) {
			server.sendShowRadio();
		} else if (e.getSource() == btn_audio_off) {
			server.sendHideRadio();
		} else if (e.getSource() == btn_audio_volume_up) {
			server.sendRadioVolume(10);
		} else if (e.getSource() == btn_audio_volume_down) {
			server.sendRadioVolume(0);
		} else if (e.getSource() == btn_start_engine) {
			server.sendEngineStarted();
		} else if (e.getSource() == btn_stop_engine) {
			server.sendEngineStopped();
		} else if (e.getSource() == btn_climate_left_on) {
			server.sendShowClimateLeft();
		} else if (e.getSource() == btn_climate_left_off) {
			server.sendHideClimateLeft();
		} else if (e.getSource() == btn_climate_right_on) {
			server.sendShowClimateRight();
		} else if (e.getSource() == btn_climate_right_off) {
			server.sendHideClimateRight();
		} else if (e.getSource() == btn_speed_slow) {
			server.changeHeardbeatSpeed(3);
		} else if (e.getSource() == btn_speed_moderate) {
			server.changeHeardbeatSpeed(2);
		} else if (e.getSource() == btn_speed_fast) {
			server.changeHeardbeatSpeed(1);
		}

		else if (e.getSource() == btn_hotspot_1) {
			server.sendHotspot(1);
		} else if (e.getSource() == btn_hotspot_2) {
			server.sendHotspot(2);
		} else if (e.getSource() == btn_hotspot_3) {
			server.sendHotspot(3);
		} else if (e.getSource() == btn_no_hotspot) {
			server.sendHotspot(0);
		} else if (e.getSource() == btn_calibrate) {
			server.sendCalibrateYaw();
		} else if (e.getSource() == btn_direction) {
			server.sendDirection();
		} else if (e.getSource() == btn_eco) {
			server.sendEco(0);
		} else if (e.getSource() == btn_agile) {
			server.sendAgile();
		}
	}

}
